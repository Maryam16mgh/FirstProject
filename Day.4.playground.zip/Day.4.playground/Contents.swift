import UIKit
var Day : Int = 4
var Lesson : String = "Review"

// Valid names:

var greeting = "Howdy!"
var _language = "Swift"
var 🌧 = "Rainy cloud"

// Invalid names:

//var 9thMonth = "Ramadan"
//var @account = "myAccunt"

print("") //Output:
print("\"") //Output: "
print("My name \t is Maryam") //Output: My name     is Maryam
print("How \nare \nyou?") //Output: How
                          //        are
                          //        you?


let result1 = 5 * 2 / 10
let result2 = 5 / 2 * 10

print("Result: \(result1)") //Result: 1
print("Result: \(result2)") //Result: 20

print("Result: \(5 * 2 / 10)") //Result: 1
print("Result: \(5 / 2 * 10)") //Result: 20


let expression1 = 90 < 100 //true
let expression2 = 90 > 100 //false

let compoundExpression1 = expression1 || expression2 //true
let compoundExpression2 = expression1 && expression2 //false
let compoundExpression3 = compoundExpression2 || expression2 //false
let compoundExpression4 = expression1 && compoundExpression1 //true


// Happy learning <3
