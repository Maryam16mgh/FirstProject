import UIKit
var Day : Int = 8
var Lesson : String = "While and Repeat-While Loop"

//While Loop
var i = 1
while i <= 5 {
    print(i)
    i += 1
}

print("\n")

// Repeat-While Loop
var j = 5
repeat{
    print(j)
    j -= 1
} while j>=1

print("\n")

//Break Keyword
var myAge = 24
while myAge > 0 {
    print(myAge)
    if myAge == 20 {
        break
    }
    myAge -= 1
}
