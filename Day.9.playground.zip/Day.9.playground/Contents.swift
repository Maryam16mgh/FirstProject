import UIKit
var Day : Int = 9
var Lesson : String = "Arrays"

var numbers = [Int]()

numbers.append(1)
numbers.append(2)

numbers.insert(4, at: 2)
numbers.insert(3, at: 2)

print(numbers.count)

numbers.remove(at: 2)

var i = 0

for i in 0...2 {
    print(numbers[i])
}
