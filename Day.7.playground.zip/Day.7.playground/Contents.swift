import UIKit
var Day : Int = 7
var Lesson : String = "For-in Loop"

// Range Type

for i in 1...7{
    print(i)
}

print("\n")

for k in 8..<11{
    print(k)
}

print("\n")

for _ in 1...3{
    print("Maryam")
}
