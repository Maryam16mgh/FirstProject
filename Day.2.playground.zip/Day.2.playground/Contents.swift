import UIKit
var Day : Int = 2
var Lesson : String = "Variables & Data Types"


let welcome : String = " Hello SWIFT Frinds 👩🏻‍💻"
print(welcome)
