import UIKit
var Day : Int = 12
var Lesson : String = "Quiz Week.2"


// Quiz 1
var grade : String = ""
var  YearsOfExperience : Int = 0

if YearsOfExperience == 0 {
    grade = " Junior Engineer I"
}
else if YearsOfExperience == 1 {
    grade = " Junior Engineer II"
}
else if YearsOfExperience == 2 || YearsOfExperience == 3 {
    grade = "Senior Engineer I"
}
else if (3<YearsOfExperience && YearsOfExperience<=5) {
    grade = "Senior Engineer II"
}
else if (5<YearsOfExperience && YearsOfExperience<=10) {
    grade = "Principal Engineer"
}
else if YearsOfExperience > 10 {
    grade = "Distinguished Engineer"
}


// Quiz 2
for n in 1..<50 {
    if n % 2 == 0 {
        print(n)
    }
}
print("\n")

// Quiz 3
var grades = [25.0 , 20.5 , 14.0 , 10.5]
print("Total = " , grades[0]+grades[1]+grades[2])
print("Avrege = " , (grades[0]+grades[1]+grades[2])/3)

print("\n")

// Quiz 4
var students = ["Mohammes" : 4.25 , "Khalid" : 4.80 , "Noura" : 4.95]
for (key,value) in students {
    print("\(key) : \(value)")
}

