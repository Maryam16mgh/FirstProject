import UIKit
var Day : Int = 5
var Lesson : String = "Quiz Week.1"


// Quiz 1
var salary = 5000
var outlay = 1000 + 700 + 1300
var saving = salary - outlay

print("Salary = " , salary)
print("Outlay = " , outlay)
print("Saving = " , saving)


// Quiz 2
var sing : String = "Smoking is not allowed"
var age : Int = 22
var speed : Double = 54.7
var iloveswift : Bool = true

// Quiz 3
let allowedToEnter = false

// Quiz 4
10 != 5 + 5 //false

// Quiz 5
let goWatchMovie = true
