import UIKit
var Day : Int = 10
var Lesson : String = "Dictionaries, and Sets"


//Dictionaries
var numbers = [String:Int]()

numbers["one"] = 1
numbers["two"] = 2
numbers["three"] = 3

print(numbers)
print(numbers["two"])
numbers.removeValue(forKey: "three")

//Sets
var name = Set<String>()

name.insert("Maryam")
name.insert("Mohammad")
name.insert("AlGhannam")

print(name)

name.remove("AlGhannam")

print(name)
