import UIKit
var Day : Int = 3
var Lesson : String = "Operators and precedence"


let juicePrice = 5.0
let chipsPrice = 10.0
let VAT = 1.05

var subtotal = (juicePrice + chipsPrice) * VAT


var number = 10
number = number + 1
number = number - 1
number = number * number

var x = 10
x += 1
x -= 1

var num1 = 1.1
var num2 = 5.5
var result = num1 + num2 // 1.1 + 5.5 -> 6.6


var name1 = "Maryam"
var name2 = "Mohammad"
var both = name1 + " and " + name2
// both = "Maryam and Mohammad"


1 == 1   // true because 1 is equal to 1
2 != 1   // true because 2 is not equal to 1
2 > 1    // true because 2 is greater than 1
1 < 2    // true because 1 is less than 2
1 >= 1   // true because 1 is greater than or equal to 1
2 <= 1   // false because 2 is not less than or equal to 1


name1 == name2
name1 != name2
name1 == "Maryam"
name1 == "Mohammad"


var itIsRaining = true
!itIsRaining // false


// Happy learning <3
